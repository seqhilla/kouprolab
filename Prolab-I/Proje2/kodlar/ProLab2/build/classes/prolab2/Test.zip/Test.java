package prolab2;

import java.awt.Graphics;
import java.awt.Image;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Test extends JPanel{

    private  Image kapalikart;
    private JFrame frame;
    private Graphics gr;
    public Test(JFrame fr,Graphics g) throws IOException {
        frame = fr;
        kapalikart = ImageIO.read(new File("2.jpg"));
        gr = g;
    }
    
    public void ekranOlustur(){
        
       
        super.paint(gr);
        gr.drawImage(kapalikart, 0, 0, this);
        
        frame.setSize(1000,1000);
        frame.setLayout(null);
        frame.setVisible(true);
        
    }
    
    Test(String t) {
        t = "Çalıştı";
        System.out.println(t);
    }
    
    public static void main(String[] args) throws IOException {

//            sporcu isimler boyle mi yapcaz emin değiim bana saçma geliyor ama pdfden onu anladım
        
//          ArrayList<String> sporcuisimleri = new ArrayList<>();
//          sporcuisimleri.add("Lionel Messi"); sporcuisimleri.add("Jamie
//          Vardy"); sporcuisimleri.add("Mohamed Salah");
//          sporcuisimleri.add("Cristiano Ronaldo"); sporcuisimleri.add("Merih
//          Demiral"); sporcuisimleri.add("Harry Kane");
//          sporcuisimleri.add("Kevin De Bruyne"); sporcuisimleri.add("Angel
//          Correa"); sporcuisimleri.add("LeBron James");// 8.index basketci
//          sporcuisimleri.add("LeBron James"); sporcuisimleri.add("LeBron
//          James"); sporcuisimleri.add("LeBron James");
//          sporcuisimleri.add("LeBron James"); sporcuisimleri.add("LeBron
//          James"); sporcuisimleri.add("LeBron James");
//          sporcuisimleri.add("LeBron James");
//         
//          ArrayList<String> sporcutakimlari = new ArrayList<>();
//          sporcutakimlari.add("FC Barcelona"); sporcutakimlari.add("Leicester
//          City FC"); sporcutakimlari.add("Liverpool FC");
//          sporcutakimlari.add("Juventus FC"); sporcutakimlari.add("Juventus
//          FC"); sporcutakimlari.add("Tottenham Hotspur");
//          sporcutakimlari.add("Manchester City"); sporcutakimlari.add("Atletico
//          Madrid"); sporcutakimlari.add("Los Angeles Lakers");// 8.inderx
//          basketci sporcutakimlari.add("Los Angeles Lakers");
//          sporcutakimlari.add("Los Angeles Lakers"); sporcutakimlari.add("Los
//          Angeles Lakers"); sporcutakimlari.add("Los Angeles Lakers");
//          sporcutakimlari.add("Los Angeles Lakers"); sporcutakimlari.add("Los
//          Angeles Lakers"); sporcutakimlari.add("Los Angeles Lakers");
//         
//          ArrayList<Sporcu> s = new ArrayList<>(); Sporcu temps; for(int i=0;
//          i<16; i++){ temps = new Sporcu();
//          temps.setSporcuIsim(sporcuisimleri.get(i));
//          temps.setSporcuTakim(sporcutakimlari.get(i)); s.add(temps); }
        
        
        
        //futbolcu degerleri atama
        //futbolcu isimlerini ayarlama
        ArrayList<String> fisimleri = new ArrayList<>();
        fisimleri.add("Lionel Messi");
        fisimleri.add("Jamie Vardy");
        fisimleri.add("Mohamed Salah");
        fisimleri.add("Cristiano Ronaldo");
        fisimleri.add("Merih Demiral");
        fisimleri.add("Harry Kane");
        fisimleri.add("Kevin De Bruyne");
        fisimleri.add("Angel Correa");

        //futbolcu takimi
        ArrayList<String> ftakimlari = new ArrayList<>();
        ftakimlari.add("FC Barcelona");
        ftakimlari.add("Leicester City FC");
        ftakimlari.add("Liverpool FC");
        ftakimlari.add("Juventus FC");
        ftakimlari.add("Juventus FC");
        ftakimlari.add("Tottenham Hotspur");
        ftakimlari.add("Manchester City");
        ftakimlari.add("Atletico Madrid");

        //futbolcu penalti
        ArrayList<Integer> fpen = new ArrayList<>();
        fpen.add(90);
        fpen.add(95);
        fpen.add(95);
        fpen.add(100);
        fpen.add(70);
        fpen.add(85);
        fpen.add(90);
        fpen.add(80);

        //futbolcu serbestAtis
        ArrayList<Integer> fserbest = new ArrayList<>();
        fserbest.add(100);
        fserbest.add(65);
        fserbest.add(70);
        fserbest.add(100);
        fserbest.add(25);
        fserbest.add(95);
        fserbest.add(85);
        fserbest.add(80);

        //futbolcu kkk(kaleci ile karsi karsiya)
        ArrayList<Integer> fkkk = new ArrayList<>();
        fkkk.add(85);
        fkkk.add(100);
        fkkk.add(100);
        fkkk.add(90);
        fkkk.add(40);
        fkkk.add(95);
        fkkk.add(90);
        fkkk.add(80);

        ArrayList<Futbolcu> f = new ArrayList<>();
        Futbolcu tempf;
        for (int i = 0; i < 8; i++) {
            tempf = new Futbolcu(fisimleri.get(i), ftakimlari.get(i));
            tempf.setPenalti(fpen.get(i));
            tempf.setSerbestAtis(fserbest.get(i));
            tempf.setKaleciKarsiKarsiya(fkkk.get(i));
            f.add(tempf);
        }
        //Test için
        /*
        for(int i=0; i<8; i++){
            System.out.println("AD: "+f.get(i).getFutbolcuAdi()+" TAKIM : "+f.get(i).getFutbolcuTakim());
            System.out.println("PEN: "+f.get(i).getPenalti()+" SERBEST VURUS: "+f.get(i).getKaleciKarsiKarsiya()+" KKK: "+f.get(i).getKaleciKarsiKarsiya());
            System.out.println("");
        }
         */

        ArrayList<String> bisimler = new ArrayList<>();
        bisimler.add("LeBron James");
        bisimler.add("Michael Jordan");
        bisimler.add("Furkan Korkmaz");
        bisimler.add("James Harden");
        bisimler.add("Stephen Curry");
        bisimler.add("Luka Doncic");
        bisimler.add("Trae Young");
        bisimler.add("Jimmy Butler");

        ArrayList<String> btakimlar = new ArrayList<>();
        btakimlar.add("Los Angeles Lakers");
        btakimlar.add("Chicago Bulls");
        btakimlar.add("Philadelphia 76ers");
        btakimlar.add("Houston Rockets");
        btakimlar.add("Golden State Warriors");
        btakimlar.add("Dallas Mavericks");
        btakimlar.add("Atlanta Hawks");
        btakimlar.add("Miami Heat");

        ArrayList<Integer> iki = new ArrayList<>();
        iki.add(98);
        iki.add(100);
        iki.add(68);
        iki.add(85);
        iki.add(80);
        iki.add(96);
        iki.add(90);
        iki.add(90);

        ArrayList<Integer> uc = new ArrayList<>();
        uc.add(95);
        uc.add(100);
        uc.add(85);
        uc.add(95);
        uc.add(95);
        uc.add(96);
        uc.add(90);
        uc.add(90);

        ArrayList<Integer> bserbest = new ArrayList<>();
        bserbest.add(90);
        bserbest.add(100);
        bserbest.add(75);
        bserbest.add(80);
        bserbest.add(95);
        bserbest.add(90);
        bserbest.add(85);
        bserbest.add(85);

        ArrayList<Basketbolcu> b = new ArrayList<>();
        Basketbolcu tempb;
        for (int i = 0; i < 8; i++) {
            tempb = new Basketbolcu(bisimler.get(i), btakimlar.get(i));
            tempb.setIkilik(iki.get(i));
            tempb.setUcluk(uc.get(i));
            tempb.setSerbestAtis(bserbest.get(i));
            b.add(tempb);
        }

//        for (int i = 0; i < 8; i++) {
//            System.out.println("AD: " + b.get(i).getBasketbolcuAdi() + " TAKIM: " + b.get(i).getBasketbolcuTakim());
//            System.out.println("IKI: " + b.get(i).getIkilik() + " UC: " + b.get(i).getUcluk() + " SERBET ATIS: " + b.get(i).getSerbestAtis());
//            System.out.println("");
//        }

        Kullanici k1 = new Kullanici(1, "Metehan", 0);
        Bilgisayar b1 = new Bilgisayar(2, "ARPANET", 0);
        // System.out.println(f.get(4).getSporcuIsim());
        //dagitim();
        //kartların dagimi için düsündügüm sey
        ArrayList<Futbolcu> futbolcukullanici = new ArrayList<>();
        ArrayList<Futbolcu> futbolcubilgisayar = new ArrayList<>();
        ArrayList<Basketbolcu> basketbolcukullanici = new ArrayList<>();
        ArrayList<Basketbolcu> basketbolcubilgisayar = new ArrayList<>();
        int r, t, dagitimindex = 8;
//        while (dagitimindex > 4) {
//
//            r = (int) (Math.random() * dagitimindex);
//            futbolcukullanici.add(f.get(r));
//            f.remove(r);
//
//            t = (int) (Math.random() * dagitimindex);
//            basketbolcukullanici.add(b.get(t));
//            b.remove(t);
//            dagitimindex--;
//        }
//        while (dagitimindex >= 0) {
//
//            r = (int) (Math.random() * dagitimindex);
//            futbolcubilgisayar.add(f.get(r));
//            f.remove(r);
//
//            t = (int) (Math.random() * dagitimindex);
//            basketbolcubilgisayar.add(b.get(t));
//            b.remove(t);
//            dagitimindex--;
//        }
        //Dagitimin sonu bu arayı methoda alabiliriz???miyiz?
        
        //Ekran olusturmaya gecis
        JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(false);
        JLabel arkaplan = new JLabel(new ImageIcon(ImageIO.read(new File("1.jpg"))));
        frame.setContentPane(arkaplan);
        Graphics g = null;
        Test oyun = new Test(frame,g);
        oyun.ekranOlustur();
        
        
        
        
        //OYUN BURDA OYNANIR
//        while (futbolcukullanici.size() >= 0 && futbolcubilgisayar.size() >= 0 && basketbolcukullanici.size() >= 0 && basketbolcubilgisayar.size() >= 0) {
//
     

    }

    static int fPozsecim() {
        int f;//futbolcu seciöleri//futbolcu basketbolcu seciöleri
        f = (int) (Math.random() * 3) + 1;
        return f;
    }

    static int bPozsecim() {
        int b;
        b = (int) (Math.random() * 3) + 1;
        return b;
    }

}
